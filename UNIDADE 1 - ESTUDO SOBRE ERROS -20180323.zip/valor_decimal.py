# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 14:59:34 2017

@author: buriol
"""

from decimal import *
print ("0.1 =", Decimal(0.1))
print ("0.2 =", Decimal(0.2))
print ("0.3 =", Decimal(0.3))
print ("3.1 =", Decimal(3.1))