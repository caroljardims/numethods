# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 15:35:09 2017

@author: buriol
"""

import sys  

print ("Máximo representável:", sys.float_info.max)

print ("Mínimo representável:", sys.float_info.min)

print ("Épsilon da máquina:", sys.float_info.epsilon)

print ("Todas informações:", sys.float_info)