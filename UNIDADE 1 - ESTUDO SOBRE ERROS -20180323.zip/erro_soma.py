# -*- coding: utf-8 -*-
"""
Created on Thu Apr 14 16:12:48 2016

@author: buriol
"""
sum = 0
for i in range(3000000):
    sum = sum + 0.11
    
print sum