# -*- coding: utf-8 -*-
"""
Created on Thu Aug 11 14:44:33 2016

@author: buriol
"""
i=1.0
while i>0:
    i = i/2.0
    print i*2
    